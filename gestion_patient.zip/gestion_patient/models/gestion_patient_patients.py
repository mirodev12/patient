# -*- coding: utf-8 -*-
from openerp import api, fields, models
from openerp import tools
from random import randint
import datetime
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, DEFAULT_SERVER_DATE_FORMAT
from odoo import SUPERUSER_ID
from dateutil import tz
import re

import logging
_logger = logging.getLogger(__name__)


class GestionPatientPatients(models.Model):

    _name = "gestion.patient.patients"
    _description = "Gestion Patient Patients"
    _order = "create_date desc"
    _rec_name ="name_patient"

    name_patient = fields.Char(string="Nom")
    prenom = fields.Char(string="Prénom")
    date_nais=fields.Date(string="Date Naissance")
    age=fields.Integer(string="Age")
    email=fields.Char(string="Email")
    adresse=fields.Text(string="Profession")
    origine=fields.Char(string="Origine")
    tel=fields.Integer(string="Téléphone")
    cin=fields.Char(string="N° Cin")
    sexe=fields.Selection([ ('homme', 'Homme'),('femme', 'Femme'),],'Sexe')
    create_user_id = fields.Many2one('res.users', "Créer Par")
class GestionPatientStade(models.Model):

    _name = "gestion.patient.stade"
    _description = "Gestion Patient Stade"
    _order = "create_date desc"
    _rec_name ="name_stade"

    name_stade = fields.Char(string="Classe")
class GestionPatientTnm(models.Model):

    _name = "gestion.patient.tnm"
    _description = "Gestion Patient Tnm"
    _order = "create_date desc"
    _rec_name ="name_tnm"

    name_tnm = fields.Char(string="Nom")
    type = fields.Char(string="type")
class GestionPatientConsultation(models.Model):

    _name = "gestion.patient.consultation"
    _description = "Gestion Patient Consultation"
    _order = "create_date desc"
    _rec_name ="num_dossier"

    tabagisme = fields.Char(string="Tabagisme")
    symptome = fields.Char(string="symptome")
    type_histologique = fields.Char(string="Type Histologique")
    localisation = fields.Char(string="Localisation")
    adenopathie = fields.Char(string="Adenopathie")
    metastase = fields.Char(string="Metastase")
    chirugie = fields.Char(string="Chirugie")
    chimiotherapie = fields.Char(string="Chimiotherapie")
    indicationCT = fields.Char(string="IndicationCT")
    radiotherapie = fields.Char(string="Radiotherapie")
    soin_palliatifs = fields.Char(string="Soin Palliatifs")
    evolution = fields.Char(string="Evolution")
    couverture_social = fields.Char(string="Couverture Social")
    stade_id=fields.Many2one('gestion.patient.stade',string="Stade")
    tnm_id=fields.Many2one('gestion.patient.tnm',string="TNM")
    num_dossier = fields.Many2one('gestion.patient.dossier',string="num_dossier")
class GestionPatientDossier(models.Model):

    _name = "gestion.patient.dossier"
    _description = "Gestion Patient Dossier"
    _order = "create_date desc"
    _rec_name ="num_dossier"

    num_dossier = fields.Char(string="Numéro Dossier")
    patient_id = fields.Many2one('gestion.patient.patients',string="Patient")
    consultation_ids=fields.One2many('gestion.patient.consultation','num_dossier',string="Consultation")

